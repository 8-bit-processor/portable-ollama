import tkinter as tk
from tkinter import scrolledtext, messagebox
import requests
import threading
from typing import Optional, Any # Import Optional and Any for type hinting

# --- Modern UI Configuration ---
BG_COLOR = "#242424"
TEXT_AREA_BG = "#363636"
TEXT_COLOR = "#EAEAEA"
ACCENT_COLOR = "#1E90FF"  # DodgerBlue
USER_MSG_COLOR = "#B0C4DE" # LightSteelBlue
FONT = ("Segoe UI", 14)
FONT_BOLD = ("Segoe UI", 14, "bold")
# -----------------------------

OLLAMA_API_URL = "http://localhost:11434/api/generate"
MODEL_NAME = "tinyllama"

class ChatbotApp:
    def __init__(self, root: tk.Tk): # Add type hint for root
        self.root: tk.Tk = root # Add type hint for instance variable
        self.root.title("Portable TinyLlama Chatbot")
        self.root.geometry("800x800")
        self.root.configure(bg=BG_COLOR)

        # --- Animation State ---
        self.is_thinking: bool = False
        self.animation_frames: list[str] = ["●    ", "● ●  ", "● ● ●", "● ●  "]
        self.animation_frame_index: int = 0
        # -------------------------

        # Main chat area
        self.chat_history = scrolledtext.ScrolledText(
            root, state='disabled', wrap=tk.WORD, bg=TEXT_AREA_BG, fg=TEXT_COLOR, font=FONT,
            padx=10, pady=10, relief=tk.FLAT, insertbackground=TEXT_COLOR
        )
        self.chat_history.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # --- Thinking Indicator Frame (packed/unpacked as needed) ---
        self.thinking_frame = tk.Frame(root, bg=BG_COLOR)
        tk.Label(self.thinking_frame, text="TinyLlama", font=FONT_BOLD, fg=ACCENT_COLOR, bg=BG_COLOR).pack(side=tk.LEFT, anchor='w')
        self.thinking_dots_label = tk.Label(self.thinking_frame, text="", font=FONT_BOLD, fg=TEXT_COLOR, bg=BG_COLOR)
        self.thinking_dots_label.pack(side=tk.LEFT, anchor='w')
        # -------------------------------------------------------------

        # Define styles for chat messages
        self.chat_history.tag_config("user_label", foreground=USER_MSG_COLOR, font=FONT_BOLD, justify='right', rmargin=5)
        self.chat_history.tag_config("user_text", foreground=TEXT_COLOR, justify='right', rmargin=5)
        self.chat_history.tag_config("ai_label", foreground=ACCENT_COLOR, font=FONT_BOLD, lmargin1=5)
        self.chat_history.tag_config("ai_text", foreground=TEXT_COLOR, lmargin1=5)
        self.chat_history.tag_config("system_label", foreground="#A9A9A9", font=FONT_BOLD, justify='center')
        self.chat_history.tag_config("system_text", foreground="#A9A9A9", justify='center')

        # Input frame
        input_frame = tk.Frame(root, bg=BG_COLOR)
        input_frame.pack(padx=10, pady=(0, 10), fill=tk.X, side=tk.BOTTOM)

        self.user_input = tk.Entry(
            input_frame, font=FONT, bg=TEXT_AREA_BG, fg=TEXT_COLOR, relief=tk.FLAT, insertbackground=TEXT_COLOR
        )
        self.user_input.bind("<Return>", self.send_message)
        self.user_input.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=8, padx=(0, 5))

        self.send_button = tk.Button(
            input_frame, text="Send", font=FONT_BOLD, command=self.send_message, relief=tk.FLAT,
            bg=ACCENT_COLOR, fg=TEXT_COLOR, activebackground="#1C86EE", activeforeground=TEXT_COLOR, width=8
        )
        self.send_button.pack(side=tk.RIGHT)
        
        self.add_message("System", f"{MODEL_NAME} listening on Localhost:Port 11434")

    def add_message(self, sender: str, message: str) -> None:
        self.chat_history.config(state='normal')
        if sender == "You":
            self.chat_history.insert(tk.END, f"{sender}\n", "user_label")
            self.chat_history.insert(tk.END, f"{message}\n\n", "user_text")
        elif sender == "System":
            self.chat_history.insert(tk.END, f"{sender}: {message}\n\n", ("system_label", "system_text"))
        else: # AI
            self.chat_history.insert(tk.END, f"{sender}\n", "ai_label")
            self.chat_history.insert(tk.END, f"{message}\n\n", "ai_text")
        self.chat_history.config(state='disabled')
        self.chat_history.yview(tk.END)

    def show_thinking_indicator(self) -> None:
        self.thinking_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=15, anchor='w')
        self.is_thinking = True
        self.animation_frame_index = 0
        self.animate_thinking()

    def hide_thinking_indicator(self) -> None:
        self.is_thinking = False
        self.thinking_frame.pack_forget()

    def animate_thinking(self) -> None:
        if not self.is_thinking:
            return
        frame = self.animation_frames[self.animation_frame_index]
        self.thinking_dots_label.config(text=frame)
        self.animation_frame_index = (self.animation_frame_index + 1) % len(self.animation_frames)
        self.root.after(400, self.animate_thinking)

    def send_message(self, event: Optional[tk.Event] = None) -> None:
        message: str = self.user_input.get()
        if not message.strip() or self.is_thinking:
            return

        self.add_message("You", message)
        self.user_input.delete(0, tk.END)
        self.user_input.config(state='disabled')
        self.send_button.config(state='disabled')

        self.show_thinking_indicator()

        thread = threading.Thread(target=self.get_ollama_response, args=(message,))
        thread.daemon = True
        thread.start()

    def get_ollama_response(self, message: str) -> None:
        try:
            payload: dict[str, Any] = {"model": MODEL_NAME, "prompt": message, "stream": False}
            response = requests.post(OLLAMA_API_URL, json=payload, timeout=90) # Increased timeout
            response.raise_for_status()
            response_data: dict[str, Any] = response.json()
            ai_message: str = response_data.get("response", "Sorry, I couldn't get a response.")
            self.root.after(0, self.update_ui_with_response, ai_message)
        except requests.exceptions.RequestException as e:
            error_message: str = f"A timeout or connection error occurred: {e}"
            self.root.after(0, self.hide_thinking_indicator)
            self.root.after(0, self.show_error, error_message)
        except Exception as e:
            error_message: str = f"An unexpected error occurred: {e}"
            self.root.after(0, self.hide_thinking_indicator)
            self.root.after(0, self.show_error, error_message)

    def update_ui_with_response(self, message: str) -> None:
        self.hide_thinking_indicator()
        self.add_message("TinyLlama", message.strip())
        self.user_input.config(state='normal')
        self.send_button.config(state='normal')
        self.user_input.focus_set()

    def show_error(self, message: str) -> None:
        messagebox.showerror("Error", message)
        self.user_input.config(state='normal')
        self.send_button.config(state='normal')


if __name__ == "__main__":
    root: tk.Tk = tk.Tk()
    app = ChatbotApp(root)
    root.mainloop()
