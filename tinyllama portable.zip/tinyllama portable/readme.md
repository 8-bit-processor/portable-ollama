# Portable TinyLlama Chatbot

This project provides a self-contained, portable chatbot application powered by Ollama and the TinyLlama model. The entire setup is designed to run from a single folder without requiring any system-wide installation of Ollama, making it completely portable and preventing system conflicts.

## Features

- **Fully Portable**: Runs entirely from its own directory. No system-wide installation of Ollama is needed.
- **Self-Contained Environment**: Manages its own models, keys, and Python dependencies, leaving your system clean.
- **Automated Setup**: The startup script handles everything automatically:
    - Sets up local paths for models and keys.
    - Starts the Ollama server in the background.
    - Checks for the `tinyllama` model and downloads it if missing.
    - Activates the Python virtual environment.
    - Launches the chatbot application.
- **Clean Shutdown**: The script ensures the Ollama server is properly shut down when the chatbot window is closed.
- **Modern UI**: A simple and clean Tkinter-based user interface for chatting.

## Requirements

- [Python 3](https://www.python.org/downloads/) installed on your system.

## How to Run

1.  **Create the Virtual Environment (First-Time Setup)**:
    - Open a command prompt or terminal in this folder and run the following command to create a Python virtual environment:
      ```sh
      python -m venv .venv
      ```

2.  **Install Dependencies (First-Time Setup)**:
    - Activate the new environment by running:
      ```sh
      .\.venv\Scripts\activate
      ```
    - Install the required Python packages:
      ```sh
      pip install -r requirements.txt
      ```
    - You can deactivate the environment now if you wish:
      ```sh
      deactivate
      ```

3.  **Launch the Chatbot**:
    - Simply double-click and run the **`run.bat`** file.
    - The script will handle the rest. On the very first launch, it will download the `tinyllama` model, which may take a few minutes. Subsequent launches will be much faster.

## How It Works

This project uses a clever batch script (`run.bat`) to create a fully portable Ollama environment.

- **`run.bat`**: This is the main script. It sets the `USERPROFILE` and `OLLAMA_MODELS` environment variables locally for the session. This tricks `ollama.exe` into using the `.\.ollama` and `.\ollama_models` folders within the project directory, rather than your system's user directory.
- **`ollama.exe`**: The Ollama server executable that runs the large language model.
- **`chatbot.py`**: The Python application with a graphical user interface that interacts with the Ollama server.
- **`.venv`**: The local Python virtual environment that holds the necessary dependencies, keeping your global Python installation clean.
- **`.ollama`**: Stores the server's cryptographic keys. By forcing this into the project folder, we make the server's identity portable.
- **`ollama_models`**: Stores the downloaded language models, such as `tinyllama`.
- **`debug.bat`**: A utility script to help troubleshoot issues by logging the output of `run.bat` to a `debug_log.txt` file.

This setup ensures that every part of the application—the server, models, keys, and dependencies—is contained within a single folder that you can move or share anywhere.